from odoo.exceptions import AccessError, UserError, ValidationError
from odoo.tests import TransactionCase, tagged


@tagged("post_install", "-at_install", "nexa_materiales")
class TestCicloCompra(TransactionCase):

    def _usuario(self, login, *grupos):
        return self.env["res.users"].create({
            "name": login, "login": login,
            "groups_id": [(6, 0, [self.env.ref("base.group_user").id]
                           + [self.env.ref(f"nexa_materiales.{g}").id for g in grupos])],
        })

    def test_ciclo_completo_encadenado(self):
        residente1 = self._usuario("residente1@test", "group_compras_residente")
        residente2 = self._usuario("residente2@test", "group_compras_residente")
        gerencia = self._usuario("gerencia@test", "group_compras_gerencia")
        compras = self._usuario("compras@test", "group_materiales_compras")
        tesoreria = self._usuario("tesoreria@test", "group_compras_tesoreria")

        # Obra A y obra B; residente 1 asignado solo a A.
        Obra = self.env["nexa.obra"].with_user(gerencia)
        obra_a = Obra.create({"codigo": "A", "nombre": "Obra A", "presupuesto_materiales": 1000,
                              "residente_ids": [(0, 0, {"usuario_id": residente1.id})]})
        obra_b = Obra.create({"codigo": "B", "nombre": "Obra B", "presupuesto_materiales": 1000,
                              "residente_ids": [(0, 0, {"usuario_id": residente2.id})]})
        material = self.env["nexa.material"].create(
            {"codigo": "T-CEM", "nombre": "Cemento prueba", "unidad_medida": "bulto"})

        # Residente 1 crea pedido en A y recibe A-P001.
        pedido_a = self.env["nexa.pedido"].with_user(residente1).create({
            "obra_id": obra_a.id, "linea_ids": [(0, 0, {"material_id": material.id, "cantidad": 10})]})
        pedido_a.action_enviar()
        self.assertEqual(pedido_a.consecutivo, "A-P001")
        self.assertEqual(pedido_a.state, "pendiente")

        # Existe un pedido de la obra B; residente 1 intenta leerlo y es rechazado.
        pedido_b = self.env["nexa.pedido"].with_user(residente2).create({
            "obra_id": obra_b.id, "linea_ids": [(0, 0, {"material_id": material.id, "cantidad": 5})]})
        pedido_b.action_enviar()
        self.assertEqual(pedido_b.consecutivo, "B-P001", "Cada obra tiene su propia serie")
        with self.assertRaises(AccessError):
            self.env["nexa.pedido"].with_user(residente1).browse(pedido_b.id).read(["consecutivo"])
        self.assertFalse(self.env["nexa.pedido"].with_user(residente1).search([("id", "=", pedido_b.id)]))

        # Gerencia aprueba.
        pedido_a.with_user(gerencia).action_aprobar()
        self.assertEqual(pedido_a.state, "aprobado")
        self.assertEqual(pedido_a.aprobado_por_id, gerencia)
        self.assertTrue(pedido_a.aprobado_en)

        # Compras crea la orden con tres opciones: 100, 130 y 90.
        orden = self.env["nexa.orden.compra"].with_user(compras).create({
            "pedido_id": pedido_a.id,
            "opcion_ids": [
                (0, 0, {"proveedor": "P100", "precio_total": 100, "plazo_entrega_dias": 5, "forma_pago": "contado"}),
                (0, 0, {"proveedor": "P130", "precio_total": 130, "plazo_entrega_dias": 1, "forma_pago": "crédito 30"}),
                (0, 0, {"proveedor": "P90", "precio_total": 90, "plazo_entrega_dias": 15, "forma_pago": "anticipo"}),
            ]})
        orden.action_enviar()
        self.assertEqual(orden.consecutivo, "A-OC001")
        opcion_130 = orden.opcion_ids.filtered(lambda o: o.precio_total == 130)

        # Gerencia elige 130 sin justificación: rechazado.
        with self.assertRaises(ValidationError):
            orden.with_user(gerencia).action_aprobar(opcion_130.id)
        self.assertEqual(orden.state, "pendiente")

        # Con justificación: pasa, y queda el rastro.
        orden.with_user(gerencia).action_aprobar(opcion_130.id, "Entrega en 1 día; la obra está parada.")
        self.assertEqual(orden.state, "aprobada")
        self.assertEqual(orden.opcion_elegida_id, opcion_130)
        self.assertEqual(orden.aprobado_por_id, gerencia)
        self.assertEqual(orden.precio_total, 130)

        # Editar la orden aprobada (orden y opciones): rechazado.
        with self.assertRaises(UserError):
            orden.with_user(compras).write({"pedido_id": pedido_a.id})
        with self.assertRaises(UserError):
            opcion_130.with_user(compras).write({"precio_total": 1})

        # Tesorería la marca pagada.
        orden.with_user(tesoreria).action_marcar_pagada("2026-09-26", "TRF-0001")
        self.assertEqual(orden.state, "pagada")
        self.assertEqual(orden.referencia_pago, "TRF-0001")
        self.assertEqual(obra_a.with_user(gerencia).gasto_comprometido, 130)
