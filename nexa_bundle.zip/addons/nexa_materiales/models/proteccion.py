"""Patrón común de protección en el servidor (extraído del módulo 1).

Cada modelo declara:
  * _CAMPOS_PROTEGIDOS: campos que ningún cliente puede escribir (calculados,
    estados, quién aprobó, consecutivos...). Solo el propio servidor los escribe
    dentro de una transición, en modo superusuario (sudo) y después de validar
    grupo y estado. Un cliente no puede activar sudo por la API.
  * _ESTADOS_BLOQUEADOS: estados en los que el registro ya no se puede editar.
  * _padre_bloqueo (opcional): campo hacia el documento padre; si el padre está
    bloqueado, el hijo tampoco se puede crear, editar ni borrar.

No se usa el contexto como "llave" porque el contexto lo controla el cliente
(cualquiera puede enviarlo por XML-RPC/JSON-RPC).
"""
from odoo import _, api, models
from odoo.exceptions import UserError


class NexaProteccionMixin(models.AbstractModel):
    _name = "nexa.proteccion.mixin"
    _description = "Protección de campos y estados en el servidor (NEXA)"

    _CAMPOS_PROTEGIDOS = frozenset()
    _ESTADOS_BLOQUEADOS = frozenset()
    _padre_bloqueo = None

    # -- utilidades -------------------------------------------------------
    def _nexa_es_servidor(self):
        return self.env.su

    def _nexa_bloqueado(self):
        """True si este registro (o su padre) ya no admite cambios."""
        self.ensure_one()
        if self._ESTADOS_BLOQUEADOS and "state" in self._fields and self.state in self._ESTADOS_BLOQUEADOS:
            return True
        if self._padre_bloqueo:
            padre = self[self._padre_bloqueo]
            return bool(padre) and padre._nexa_bloqueado()
        return False

    def _nexa_rechazar_protegidos(self, vals):
        if self._nexa_es_servidor():
            return
        prohibidos = set(self._CAMPOS_PROTEGIDOS).intersection(vals)
        if prohibidos:
            raise UserError(_(
                "Estos campos los calcula o los fija el sistema y no se pueden escribir: %s",
                ", ".join(sorted(prohibidos)),
            ))

    def _nexa_rechazar_si_bloqueado(self, accion):
        if self._nexa_es_servidor():
            return
        for rec in self:
            if rec._nexa_bloqueado():
                raise UserError(_(
                    "%(doc)s ya no se puede %(accion)s en su estado actual.",
                    doc=rec.display_name or rec._description, accion=accion,
                ))

    # -- ORM ----------------------------------------------------------------
    @api.model_create_multi
    def create(self, vals_list):
        for vals in vals_list:
            self._nexa_rechazar_protegidos(vals)
            if self._padre_bloqueo and vals.get(self._padre_bloqueo) and not self._nexa_es_servidor():
                padre = self.env[self._fields[self._padre_bloqueo].comodel_name].browse(vals[self._padre_bloqueo])
                if padre._nexa_bloqueado():
                    raise UserError(_("%s ya no admite cambios en su estado actual.", padre.display_name))
        return super().create(vals_list)

    def write(self, vals):
        self._nexa_rechazar_protegidos(vals)
        self._nexa_rechazar_si_bloqueado(_("editar"))
        return super().write(vals)

    def unlink(self):
        self._nexa_rechazar_si_bloqueado(_("borrar"))
        return super().unlink()
