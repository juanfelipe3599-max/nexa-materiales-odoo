from odoo import _, api, fields, models
from odoo.exceptions import UserError

ESTADOS_OC_GASTO = ("aprobada", "pagada")


class NexaObra(models.Model):
    """La obra es la llave: todo pedido y toda orden de compra la llevan."""

    _name = "nexa.obra"
    _inherit = ["nexa.proteccion.mixin", "mail.thread"]
    _description = "Obra"
    _order = "codigo"
    _rec_names_search = ["codigo", "nombre"]

    codigo = fields.Char(string="Código", required=True, index=True, tracking=True,
                         help="Formato real de la empresa, por ejemplo CT-2600-06.")
    nombre = fields.Char(string="Nombre", required=True, tracking=True)
    active = fields.Boolean(string="Activo", default=True, tracking=True)
    # Moneda y país viven en la obra desde el primer día (decisión de arquitectura).
    currency_id = fields.Many2one("res.currency", string="Moneda", required=True,
                                  default=lambda s: s.env.company.currency_id)
    country_id = fields.Many2one("res.country", string="País", required=True,
                                 default=lambda s: s.env.company.country_id or s.env.ref("base.co"))
    presupuesto_materiales = fields.Monetary(string="Presupuesto de materiales",
                                             currency_field="currency_id", tracking=True)
    residente_ids = fields.One2many("nexa.obra.residente", "obra_id", string="Residentes asignados")
    pedido_ids = fields.One2many("nexa.pedido", "obra_id", string="Pedidos")

    # Series independientes por obra. Se usan secuencias de PostgreSQL
    # (ir.sequence "standard"): dos transacciones simultáneas nunca reciben el
    # mismo número. Puede haber huecos si una transacción se revierte.
    secuencia_pedido_id = fields.Many2one("ir.sequence", readonly=True, copy=False)
    secuencia_oc_id = fields.Many2one("ir.sequence", readonly=True, copy=False)

    gasto_comprometido = fields.Monetary(
        string="Gastado en materiales", currency_field="currency_id",
        compute="_compute_gasto",
        groups="nexa_materiales.group_compras_gerencia,nexa_materiales.group_materiales_compras,nexa_materiales.group_compras_tesoreria",
        help="Suma del precio de la opción elegida en las órdenes aprobadas o pagadas de la obra.",
    )
    gasto_pct = fields.Float(
        string="% del presupuesto", compute="_compute_gasto", digits=(16, 1),
        groups="nexa_materiales.group_compras_gerencia,nexa_materiales.group_materiales_compras,nexa_materiales.group_compras_tesoreria",
    )

    _CAMPOS_PROTEGIDOS = frozenset({"secuencia_pedido_id", "secuencia_oc_id"})

    _sql_constraints = [
        ("codigo_unico", "unique(codigo)", "Ya existe una obra con ese código."),
        ("presupuesto_no_negativo", "CHECK(presupuesto_materiales >= 0)",
         "El presupuesto de materiales no puede ser negativo."),
    ]

    def _compute_gasto(self):
        ordenes = self.env["nexa.orden.compra"].sudo().search([
            ("obra_id", "in", self.ids), ("state", "in", ESTADOS_OC_GASTO)])
        for obra in self:
            total = sum(o.precio_total for o in ordenes if o.obra_id == obra)
            obra.gasto_comprometido = total
            obra.gasto_pct = (total / obra.presupuesto_materiales * 100.0) if obra.presupuesto_materiales else 0.0

    @api.depends("codigo", "nombre")
    def _compute_display_name(self):
        for obra in self:
            obra.display_name = f"{obra.codigo} · {obra.nombre}" if obra.codigo else obra.nombre

    @api.model_create_multi
    def create(self, vals_list):
        for vals in vals_list:
            if vals.get("codigo"):
                vals["codigo"] = vals["codigo"].strip().upper()
        obras = super().create(vals_list)
        Seq = self.env["ir.sequence"].sudo()
        for obra in obras:
            obra.sudo().write({
                "secuencia_pedido_id": Seq.create({
                    "name": f"Pedidos {obra.codigo}", "prefix": f"{obra.codigo}-P",
                    "padding": 3, "implementation": "standard", "company_id": False}).id,
                "secuencia_oc_id": Seq.create({
                    "name": f"Órdenes de compra {obra.codigo}", "prefix": f"{obra.codigo}-OC",
                    "padding": 3, "implementation": "standard", "company_id": False}).id,
            })
        return obras

    def write(self, vals):
        if "codigo" in vals and not self.env.su:
            if any(o.pedido_ids for o in self):
                raise UserError(_("No se puede cambiar el código de una obra que ya tiene pedidos: "
                                  "sus consecutivos dependen de él."))
            vals["codigo"] = vals["codigo"].strip().upper()
        res = super().write(vals)
        if "codigo" in vals:
            for obra in self:
                obra.secuencia_pedido_id.sudo().prefix = f"{obra.codigo}-P"
                obra.secuencia_oc_id.sudo().prefix = f"{obra.codigo}-OC"
        return res

    def unlink(self):
        raise UserError(_("Las obras no se borran; archívelas."))

    def _siguiente_consecutivo(self, tipo):
        """Único punto que entrega consecutivos. Se ejecuta en el servidor."""
        self.ensure_one()
        seq = self.sudo().secuencia_pedido_id if tipo == "pedido" else self.sudo().secuencia_oc_id
        return seq.next_by_id()


class NexaObraResidente(models.Model):
    """Qué residente ve qué obra. Es la base del aislamiento por obra."""

    _name = "nexa.obra.residente"
    _description = "Residente asignado a obra"
    _rec_name = "usuario_id"

    obra_id = fields.Many2one("nexa.obra", string="Obra", required=True, ondelete="cascade", index=True)
    usuario_id = fields.Many2one("res.users", string="Residente", required=True, ondelete="cascade", index=True,
                                 domain=lambda s: [("groups_id", "in", s.env.ref("nexa_materiales.group_compras_residente").id)])

    _sql_constraints = [
        ("unico", "unique(obra_id, usuario_id)", "Ese residente ya está asignado a la obra."),
    ]
