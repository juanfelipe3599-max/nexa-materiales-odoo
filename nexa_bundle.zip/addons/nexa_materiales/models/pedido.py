from odoo import _, api, fields, models
from odoo.exceptions import AccessError, UserError, ValidationError

G_RESIDENTE = "nexa_materiales.group_compras_residente"
G_GERENCIA = "nexa_materiales.group_compras_gerencia"
G_COMPRAS = "nexa_materiales.group_materiales_compras"
G_TESORERIA = "nexa_materiales.group_compras_tesoreria"


def exigir_grupo(env, grupo, accion):
    if not env.user.has_group(grupo):
        raise AccessError(_("Su perfil no puede %s.", accion))


class NexaPedido(models.Model):
    """Pedido de material de una obra. Borrador → pendiente → aprobado | rechazado."""

    _name = "nexa.pedido"
    _inherit = ["nexa.proteccion.mixin", "mail.thread"]
    _description = "Pedido de material"
    _order = "fecha desc, id desc"
    _rec_name = "consecutivo"

    consecutivo = fields.Char(string="Consecutivo", readonly=True, copy=False, index=True,
                              help="Se asigna al enviar: {código de obra}-P###, serie propia de cada obra.")
    obra_id = fields.Many2one("nexa.obra", string="Obra", required=True, index=True, ondelete="restrict",
                              tracking=True)
    solicitante_id = fields.Many2one("res.users", string="Solicitante", required=True, readonly=True,
                                     default=lambda s: s.env.user, ondelete="restrict")
    fecha = fields.Date(string="Fecha", required=True, default=fields.Date.context_today)
    urgente = fields.Boolean(string="Urgente", tracking=True)
    state = fields.Selection([
        ("borrador", "Borrador"), ("pendiente", "Pendiente"),
        ("aprobado", "Aprobado"), ("rechazado", "Rechazado"),
    ], string="Estado", default="borrador", required=True, readonly=True, tracking=True, copy=False)
    motivo_rechazo = fields.Text(string="Motivo de rechazo", readonly=True, tracking=True, copy=False)
    aprobado_por_id = fields.Many2one("res.users", string="Aprobado/rechazado por", readonly=True,
                                      tracking=True, copy=False)
    aprobado_en = fields.Datetime(string="Fecha de decisión", readonly=True, tracking=True, copy=False)
    linea_ids = fields.One2many("nexa.pedido.linea", "pedido_id", string="Materiales")
    orden_ids = fields.One2many("nexa.orden.compra", "pedido_id", string="Orden de compra")

    # Lo que gerencia ve al decidir: cuánto lleva gastado la obra vs. su presupuesto.
    currency_id = fields.Many2one(related="obra_id.currency_id")
    presupuesto_obra = fields.Monetary(related="obra_id.presupuesto_materiales", string="Presupuesto de materiales")
    gasto_obra = fields.Monetary(related="obra_id.gasto_comprometido", string="Gastado en la obra")
    gasto_obra_pct = fields.Float(related="obra_id.gasto_pct", string="% del presupuesto")

    _CAMPOS_PROTEGIDOS = frozenset({"consecutivo", "state", "motivo_rechazo", "aprobado_por_id",
                                    "aprobado_en", "solicitante_id"})
    _ESTADOS_BLOQUEADOS = frozenset({"pendiente", "aprobado", "rechazado"})

    _sql_constraints = [
        ("consecutivo_unico_por_obra", "unique(obra_id, consecutivo)",
         "Ese consecutivo ya existe en la obra."),
        ("rechazo_con_motivo",
         "CHECK(state <> 'rechazado' OR (motivo_rechazo IS NOT NULL AND length(btrim(motivo_rechazo)) > 0))",
         "Un pedido rechazado debe tener motivo de rechazo."),
        ("decision_registrada",
         "CHECK(state NOT IN ('aprobado', 'rechazado') OR (aprobado_por_id IS NOT NULL AND aprobado_en IS NOT NULL))",
         "Toda decisión debe registrar quién y cuándo."),
    ]

    @api.depends("consecutivo", "obra_id")
    def _compute_display_name(self):
        for p in self:
            p.display_name = p.consecutivo or _("Borrador (%s)", p.obra_id.codigo or "-")

    # -- transiciones (todas en el servidor) -------------------------------
    def action_enviar(self):
        self.check_access("write")
        for p in self:
            if p.state != "borrador":
                raise UserError(_("Solo un pedido en borrador se puede enviar."))
            if not p.linea_ids:
                raise UserError(_("Agregue al menos un material antes de enviar el pedido."))
            if p.solicitante_id != self.env.user and not self.env.user.has_group(G_GERENCIA):
                raise AccessError(_("Solo quien creó el pedido puede enviarlo."))
            p.sudo().write({"state": "pendiente",
                            "consecutivo": p.obra_id._siguiente_consecutivo("pedido")})
            p._message_log(body=_("Pedido enviado para aprobación."))
        return True

    def action_aprobar(self):
        exigir_grupo(self.env, G_GERENCIA, _("aprobar pedidos"))
        self.check_access("write")
        for p in self:
            if p.state != "pendiente":
                raise UserError(_("Solo un pedido pendiente se puede aprobar (estado actual: %s).", p.state))
            p.sudo().write({"state": "aprobado", "aprobado_por_id": self.env.user.id,
                            "aprobado_en": fields.Datetime.now()})
            p._message_log(body=_("Aprobado por %s.", self.env.user.name))
        return True

    def action_rechazar(self, motivo):
        exigir_grupo(self.env, G_GERENCIA, _("rechazar pedidos"))
        self.check_access("write")
        motivo = (motivo or "").strip()
        if not motivo:
            raise ValidationError(_("Para rechazar un pedido debe escribir el motivo."))
        for p in self:
            if p.state != "pendiente":
                raise UserError(_("Solo un pedido pendiente se puede rechazar (estado actual: %s).", p.state))
            p.sudo().write({"state": "rechazado", "motivo_rechazo": motivo,
                            "aprobado_por_id": self.env.user.id, "aprobado_en": fields.Datetime.now()})
            p._message_log(body=_("Rechazado por %(u)s. Motivo: %(m)s", u=self.env.user.name, m=motivo))
        return True

    def action_abrir_rechazo(self):
        return {"type": "ir.actions.act_window", "name": _("Rechazar pedido"), "res_model": "nexa.pedido.rechazo.wizard",
                "view_mode": "form", "target": "new", "context": {"default_pedido_id": self.id}}

    def unlink(self):
        raise UserError(_("Los pedidos no se borran: son parte del rastro de compras."))


class NexaPedidoLinea(models.Model):
    _name = "nexa.pedido.linea"
    _inherit = ["nexa.proteccion.mixin"]
    _description = "Línea de pedido de material"
    _padre_bloqueo = "pedido_id"

    pedido_id = fields.Many2one("nexa.pedido", string="Pedido", required=True, ondelete="cascade", index=True)
    material_id = fields.Many2one("nexa.material", string="Material", required=True, ondelete="restrict",
                                  domain=[("active", "=", True)])
    unidad_medida = fields.Char(related="material_id.unidad_medida", string="Unidad")
    cantidad = fields.Float(string="Cantidad", required=True, digits=(16, 3))

    _sql_constraints = [
        ("cantidad_positiva", "CHECK(cantidad > 0)", "La cantidad debe ser mayor que cero."),
    ]


class NexaPedidoRechazoWizard(models.TransientModel):
    _name = "nexa.pedido.rechazo.wizard"
    _description = "Rechazar pedido"

    pedido_id = fields.Many2one("nexa.pedido", required=True)
    motivo = fields.Text(string="Motivo del rechazo", required=True)

    def action_confirmar(self):
        self.pedido_id.action_rechazar(self.motivo)
        return {"type": "ir.actions.act_window_close"}
