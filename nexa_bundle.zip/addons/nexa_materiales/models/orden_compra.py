from odoo import _, api, fields, models
from odoo.exceptions import UserError, ValidationError
from odoo.tools import float_compare

from .pedido import G_COMPRAS, G_GERENCIA, G_TESORERIA, exigir_grupo

MAX_OPCIONES = 3


class NexaOrdenCompra(models.Model):
    """Orden de compra de un pedido aprobado. Borrador → pendiente → aprobada → pagada."""

    _name = "nexa.orden.compra"
    _inherit = ["nexa.proteccion.mixin", "mail.thread"]
    _description = "Orden de compra"
    _order = "id desc"
    _rec_name = "consecutivo"

    consecutivo = fields.Char(string="Consecutivo", readonly=True, copy=False, index=True,
                              help="Se asigna al enviar: {código de obra}-OC###, serie propia de cada obra.")
    pedido_id = fields.Many2one("nexa.pedido", string="Pedido", required=True, ondelete="restrict", index=True,
                                domain=[("state", "=", "aprobado"), ("orden_ids", "=", False)])
    obra_id = fields.Many2one(related="pedido_id.obra_id", store=True, index=True, string="Obra")
    state = fields.Selection([
        ("borrador", "Borrador"), ("pendiente", "Pendiente"),
        ("aprobada", "Aprobada"), ("pagada", "Pagada"),
    ], string="Estado", default="borrador", required=True, readonly=True, tracking=True, copy=False)
    opcion_ids = fields.One2many("nexa.opcion.cotizacion", "orden_id", string="Opciones de proveedor")
    opcion_elegida_id = fields.Many2one("nexa.opcion.cotizacion", string="Opción elegida", readonly=True,
                                        tracking=True, copy=False)
    justificacion_eleccion = fields.Text(string="Justificación de la elección", readonly=True, tracking=True,
                                         copy=False)
    aprobado_por_id = fields.Many2one("res.users", string="Aprobada por", readonly=True, tracking=True, copy=False)
    aprobado_en = fields.Datetime(string="Aprobada en", readonly=True, tracking=True, copy=False)
    pagado_en = fields.Date(string="Pagada en", readonly=True, tracking=True, copy=False)
    referencia_pago = fields.Char(string="Referencia de pago", readonly=True, tracking=True, copy=False)
    pagado_por_id = fields.Many2one("res.users", string="Pago registrado por", readonly=True, tracking=True,
                                    copy=False)

    currency_id = fields.Many2one(related="obra_id.currency_id")
    precio_total = fields.Monetary(string="Valor de la orden", related="opcion_elegida_id.precio_total",
                                   store=True, currency_field="currency_id")
    linea_ids = fields.One2many(related="pedido_id.linea_ids", string="Materiales del pedido")
    presupuesto_obra = fields.Monetary(related="obra_id.presupuesto_materiales", string="Presupuesto de materiales")
    gasto_obra = fields.Monetary(related="obra_id.gasto_comprometido", string="Gastado en la obra")

    _CAMPOS_PROTEGIDOS = frozenset({"consecutivo", "state", "opcion_elegida_id", "justificacion_eleccion",
                                    "aprobado_por_id", "aprobado_en", "pagado_en", "referencia_pago",
                                    "pagado_por_id", "obra_id", "precio_total"})
    # Enviada a aprobación ya no se edita; aprobada y pagada, menos.
    _ESTADOS_BLOQUEADOS = frozenset({"pendiente", "aprobada", "pagada"})

    _sql_constraints = [
        ("un_pedido_una_orden", "unique(pedido_id)", "Ese pedido ya tiene orden de compra."),
        ("consecutivo_unico_por_obra", "unique(obra_id, consecutivo)", "Ese consecutivo ya existe en la obra."),
        ("aprobacion_registrada",
         "CHECK(state NOT IN ('aprobada', 'pagada') OR (opcion_elegida_id IS NOT NULL "
         "AND aprobado_por_id IS NOT NULL AND aprobado_en IS NOT NULL))",
         "Una orden aprobada debe registrar opción, quién y cuándo."),
        ("pago_registrado",
         "CHECK(state <> 'pagada' OR (pagado_en IS NOT NULL AND referencia_pago IS NOT NULL))",
         "Una orden pagada debe registrar fecha y referencia de pago."),
    ]

    @api.depends("consecutivo", "obra_id")
    def _compute_display_name(self):
        for o in self:
            o.display_name = o.consecutivo or _("OC borrador (%s)", o.obra_id.codigo or "-")

    @api.constrains("pedido_id")
    def _check_pedido_aprobado(self):
        for o in self:
            if o.pedido_id.state != "aprobado":
                raise ValidationError(_(
                    "Solo un pedido aprobado se convierte en orden de compra "
                    "(el pedido %(p)s está %(e)s).", p=o.pedido_id.display_name, e=o.pedido_id.state))

    @api.model_create_multi
    def create(self, vals_list):
        exigir_grupo(self.env, G_COMPRAS, _("crear órdenes de compra"))
        return super().create(vals_list)

    # -- transiciones ------------------------------------------------------
    def action_enviar(self):
        exigir_grupo(self.env, G_COMPRAS, _("enviar órdenes de compra"))
        self.check_access("write")
        for o in self:
            if o.state != "borrador":
                raise UserError(_("Solo una orden en borrador se puede enviar."))
            if not o.opcion_ids:
                raise UserError(_("Registre al menos una opción de proveedor antes de enviar."))
            o.sudo().write({"state": "pendiente", "consecutivo": o.obra_id._siguiente_consecutivo("oc")})
            o._message_log(body=_("Orden enviada a aprobación con %s opción(es).", len(o.opcion_ids)))
        return True

    def action_aprobar(self, opcion_id, justificacion=None):
        exigir_grupo(self.env, G_GERENCIA, _("aprobar órdenes de compra"))
        self.check_access("write")
        self.ensure_one()
        o = self
        if o.state != "pendiente":
            raise UserError(_("Solo una orden pendiente se puede aprobar (estado actual: %s).", o.state))
        opcion = self.env["nexa.opcion.cotizacion"].browse(int(opcion_id))
        if opcion not in o.opcion_ids:
            raise ValidationError(_("La opción elegida no pertenece a esta orden."))
        mas_barata = min(o.opcion_ids.mapped("precio_total"))
        justificacion = (justificacion or "").strip()
        no_es_la_mas_barata = float_compare(opcion.precio_total, mas_barata,
                                            precision_rounding=o.currency_id.rounding or 0.01) > 0
        if no_es_la_mas_barata and not justificacion:
            raise ValidationError(_(
                "La opción elegida (%(e)s) no es la de menor precio (%(m)s). "
                "Escriba la justificación de la elección.",
                e=o.currency_id.format(opcion.precio_total), m=o.currency_id.format(mas_barata)))
        o.sudo().write({"state": "aprobada", "opcion_elegida_id": opcion.id,
                        "justificacion_eleccion": justificacion or False,
                        "aprobado_por_id": self.env.user.id, "aprobado_en": fields.Datetime.now()})
        o._message_log(body=_("Aprobada por %(u)s eligiendo %(p)s por %(v)s.%(j)s",
                              u=self.env.user.name, p=opcion.proveedor,
                              v=o.currency_id.format(opcion.precio_total),
                              j=(" " + _("Justificación: %s", justificacion)) if justificacion else ""))
        return True

    def action_marcar_pagada(self, fecha, referencia):
        exigir_grupo(self.env, G_TESORERIA, _("registrar pagos"))
        self.check_access("write")
        referencia = (referencia or "").strip()
        if not fecha or not referencia:
            raise ValidationError(_("Para marcar como pagada indique fecha y referencia de pago."))
        for o in self:
            if o.state != "aprobada":
                raise UserError(_("Solo una orden aprobada se puede marcar como pagada (estado actual: %s).", o.state))
            o.sudo().write({"state": "pagada", "pagado_en": fecha, "referencia_pago": referencia,
                            "pagado_por_id": self.env.user.id})
            o._message_log(body=_("Pago registrado por %(u)s. Referencia: %(r)s", u=self.env.user.name, r=referencia))
        return True

    def action_abrir_aprobacion(self):
        return {"type": "ir.actions.act_window", "name": _("Aprobar orden de compra"), "res_model": "nexa.orden.aprobar.wizard", "view_mode": "form",
                "target": "new", "context": {"default_orden_id": self.id}}

    def action_abrir_pago(self):
        return {"type": "ir.actions.act_window", "name": _("Registrar pago"), "res_model": "nexa.orden.pago.wizard", "view_mode": "form",
                "target": "new", "context": {"default_orden_id": self.id}}

    def unlink(self):
        raise UserError(_("Las órdenes de compra no se borran: son parte del rastro de compras."))


class NexaOpcionCotizacion(models.Model):
    _name = "nexa.opcion.cotizacion"
    _inherit = ["nexa.proteccion.mixin"]
    _description = "Opción de cotización de proveedor"
    _order = "precio_total, id"
    _rec_name = "proveedor"
    _padre_bloqueo = "orden_id"

    orden_id = fields.Many2one("nexa.orden.compra", string="Orden", required=True, ondelete="cascade", index=True)
    currency_id = fields.Many2one(related="orden_id.currency_id")
    proveedor = fields.Char(string="Proveedor", required=True)
    precio_total = fields.Monetary(string="Precio total", required=True, currency_field="currency_id")
    plazo_entrega_dias = fields.Integer(string="Plazo de entrega (días)", required=True)
    forma_pago = fields.Char(string="Forma de pago", required=True, help="Ej.: contado, crédito 30 días, 50 % anticipo.")
    es_mas_barata = fields.Boolean(string="Menor precio", compute="_compute_es_mas_barata")

    _sql_constraints = [
        ("precio_positivo", "CHECK(precio_total > 0)", "El precio total debe ser mayor que cero."),
        ("plazo_no_negativo", "CHECK(plazo_entrega_dias >= 0)", "El plazo de entrega no puede ser negativo."),
    ]

    @api.depends("orden_id.opcion_ids.precio_total")
    def _compute_es_mas_barata(self):
        for op in self:
            precios = op.orden_id.opcion_ids.mapped("precio_total")
            op.es_mas_barata = bool(precios) and op.precio_total == min(precios)

    @api.constrains("orden_id")
    def _check_maximo(self):
        for orden in self.mapped("orden_id"):
            if len(orden.opcion_ids) > MAX_OPCIONES:
                raise ValidationError(_("Una orden de compra admite máximo %s opciones de proveedor.", MAX_OPCIONES))

    @api.model_create_multi
    def create(self, vals_list):
        exigir_grupo(self.env, G_COMPRAS, _("registrar opciones de proveedor"))
        return super().create(vals_list)


class NexaOrdenAprobarWizard(models.TransientModel):
    _name = "nexa.orden.aprobar.wizard"
    _description = "Aprobar orden de compra"

    orden_id = fields.Many2one("nexa.orden.compra", required=True)
    opcion_id = fields.Many2one("nexa.opcion.cotizacion", string="Opción elegida", required=True,
                                domain="[('orden_id', '=', orden_id)]")
    requiere_justificacion = fields.Boolean(compute="_compute_requiere")
    justificacion = fields.Text(string="Justificación")

    @api.depends("opcion_id")
    def _compute_requiere(self):
        for w in self:
            w.requiere_justificacion = bool(w.opcion_id) and not w.opcion_id.es_mas_barata

    def action_confirmar(self):
        self.orden_id.action_aprobar(self.opcion_id.id, self.justificacion)
        return {"type": "ir.actions.act_window_close"}


class NexaOrdenPagoWizard(models.TransientModel):
    _name = "nexa.orden.pago.wizard"
    _description = "Registrar pago de orden de compra"

    orden_id = fields.Many2one("nexa.orden.compra", required=True)
    fecha = fields.Date(string="Fecha de pago", required=True, default=fields.Date.context_today)
    referencia = fields.Char(string="Referencia de pago", required=True)

    def action_confirmar(self):
        self.orden_id.action_marcar_pagada(self.fecha, self.referencia)
        return {"type": "ir.actions.act_window_close"}
