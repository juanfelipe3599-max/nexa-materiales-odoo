{
    "name": "NEXA · Materiales y ciclo de compra",
    "summary": "Catálogo único de materiales con precio vigente calculado "
               "desde las compras y alerta de desvío de precio.",
    "description": """
Referencia única de materiales para presupuestos y órdenes de compra.

* precio_vigente = precio unitario de la compra más reciente (calculado en servidor).
* es_desvio = la compra varía más de 15 % frente a la inmediatamente anterior.
* Dos perfiles: Compras (lee y escribe) y Consulta (solo lee), aplicados en el ORM.
* Los materiales nunca se borran: se archivan.

* Versión 2, ciclo de compra por obra: pedido, aprobación, orden con hasta tres
  opciones de proveedor, aprobación eligiendo proveedor y pago. Consecutivos por
  obra, aislamiento por obra para residentes y rastro de quién aprobó, cuándo y por qué.
""",
    "version": "18.0.2.0.0",
    "category": "Inventory/Purchase",
    "author": "NEXA",
    "license": "LGPL-3",
    "depends": ["base", "web", "mail"],
    "data": [
        "security/nexa_materiales_security.xml",
        "security/compras_security.xml",
        "security/ir.model.access.csv",
        "views/precio_compra_views.xml",
        "views/material_views.xml",
        "views/menus.xml",
        "views/compras_views.xml",
    ],
    "application": True,
    "installable": True,
}
