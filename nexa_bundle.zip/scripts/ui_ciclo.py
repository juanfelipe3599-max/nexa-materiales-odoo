"""Recorrido de interfaz del ciclo de compra (navegador real).

Prepara por API un pedido aprobado con orden de 3 opciones (100/130/90), y luego en pantalla:
gerencia aprueba eligiendo 130 sin justificación (rechazado), con justificación (pasa);
el residente 1 ve sus pedidos en celular.
Variables: ODOO_URL, ODOO_DB, NEXA_{RESIDENTE1,GERENCIA,COMPRAS}_{LOGIN,PASSWORD}, SHOTS_DIR, NEXA_OBRA_A
"""
import os
import time
import xmlrpc.client

from playwright.sync_api import sync_playwright

URL = os.environ["ODOO_URL"].rstrip("/")
DB = os.environ["ODOO_DB"]
OUT = os.environ.get("SHOTS_DIR", "shots")
OBRA_A = os.environ.get("NEXA_OBRA_A", "CT-2600-06")
os.makedirs(OUT, exist_ok=True)


def api(perfil):
    login, pwd = os.environ[f"NEXA_{perfil}_LOGIN"], os.environ[f"NEXA_{perfil}_PASSWORD"]
    uid = xmlrpc.client.ServerProxy(f"{URL}/xmlrpc/2/common").authenticate(DB, login, pwd, {})
    obj = xmlrpc.client.ServerProxy(f"{URL}/xmlrpc/2/object", allow_none=True)
    return lambda m, f, *a, **k: obj.execute_kw(DB, uid, pwd, m, f, list(a), k)


r1, ger, com = api("RESIDENTE1"), api("GERENCIA"), api("COMPRAS")
obra = ger("nexa.obra", "search", [("codigo", "=", OBRA_A)])[0]
mats = com("nexa.material", "search", [], limit=2)
pedido = r1("nexa.pedido", "create", {"obra_id": obra, "urgente": True, "linea_ids": [
    (0, 0, {"material_id": m, "cantidad": c}) for m, c in zip(mats, (40, 12))]})
r1("nexa.pedido", "action_enviar", [pedido])
ger("nexa.pedido", "action_aprobar", [pedido])
oc = com("nexa.orden.compra", "create", {"pedido_id": pedido, "opcion_ids": [
    (0, 0, {"proveedor": "Ferretería El Maestro", "precio_total": 100, "plazo_entrega_dias": 5, "forma_pago": "Contado"}),
    (0, 0, {"proveedor": "Distribuidora Andina", "precio_total": 130, "plazo_entrega_dias": 1, "forma_pago": "Crédito 30 días"}),
    (0, 0, {"proveedor": "Materiales del Valle", "precio_total": 90, "plazo_entrega_dias": 15, "forma_pago": "Anticipo 50 %"})]})
com("nexa.orden.compra", "action_enviar", [oc])
print("orden preparada:", com("nexa.orden.compra", "read", [oc], fields=["consecutivo"])[0]["consecutivo"])


def login(page, perfil):
    page.goto(f"{URL}/web/login")
    page.fill("input[name=login]", os.environ[f"NEXA_{perfil}_LOGIN"])
    page.fill("input[name=password]", os.environ[f"NEXA_{perfil}_PASSWORD"])
    page.click("button[type=submit]")
    page.wait_for_selector(".o_main_navbar", timeout=30000)


def esperar(page, sel=".o_action_manager .o_view_controller"):
    page.wait_for_selector(sel, timeout=30000)
    time.sleep(1.5)


with sync_playwright() as p:
    b = p.chromium.launch()
    ctx = b.new_context(viewport={"width": 1366, "height": 900}, locale="es-CO", timezone_id="America/Bogota")
    page = ctx.new_page()
    login(page, "GERENCIA")
    page.goto(f"{URL}/odoo/action-nexa_materiales.nexa_pedido_action/{pedido}"); esperar(page)
    page.screenshot(path=f"{OUT}/m2_1_pedido_gerencia.png", full_page=True)
    page.goto(f"{URL}/odoo/action-nexa_materiales.nexa_orden_action/{oc}"); esperar(page)
    page.screenshot(path=f"{OUT}/m2_2_orden_pendiente.png", full_page=True)
    page.click("button[name=action_abrir_aprobacion]"); esperar(page, ".modal div[name=opcion_id] input")
    campo = page.locator(".modal div[name=opcion_id] input")
    campo.fill("Andina")
    page.wait_for_selector(".o-autocomplete--dropdown-menu li a", timeout=15000)
    page.locator(".o-autocomplete--dropdown-menu li a").first.click(); time.sleep(1.5)
    page.screenshot(path=f"{OUT}/m2_3_asistente_aprobacion.png")
    page.locator(".modal button[name=action_confirmar]").click()
    page.wait_for_selector(".o_error_dialog, .o_notification", timeout=15000); time.sleep(1)
    page.screenshot(path=f"{OUT}/m2_4_sin_justificacion_rechazado.png")
    texto = page.locator(".o_error_dialog, .o_notification").first.inner_text()
    print("sin justificación ->", " ".join(texto.split())[:160])
    # La pantalla lo marca obligatorio antes de enviar; el servidor lo exige igual (ver prueba y demo por API).
    if page.locator(".o_error_dialog").count():
        page.locator(".o_error_dialog .btn-primary").first.click(); time.sleep(1)
    page.locator(".modal div[name=justificacion] textarea").fill("Entrega en 1 día; la obra está detenida esperando el material.")
    page.locator(".modal button[name=action_confirmar]").click(); time.sleep(2.5)
    page.screenshot(path=f"{OUT}/m2_5_orden_aprobada.png", full_page=True)
    print("estado final:", ger("nexa.orden.compra", "read", [oc], fields=["state"])[0]["state"])
    ctx.close()

    ctx = b.new_context(viewport={"width": 390, "height": 844}, device_scale_factor=2, is_mobile=True,
                        has_touch=True, locale="es-CO", timezone_id="America/Bogota")
    page = ctx.new_page()
    login(page, "RESIDENTE1")
    page.goto(f"{URL}/odoo/action-nexa_materiales.nexa_pedido_action"); esperar(page)
    page.screenshot(path=f"{OUT}/m2_6_residente_celular.png")
    ctx.close()
    b.close()
