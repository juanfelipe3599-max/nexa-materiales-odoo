"""Demostración por API (XML-RPC, como un script o un agente) del ciclo de compra.

1. Aislamiento por obra: el residente 1 no puede leer, buscar, editar ni aprobar
   un pedido de una obra que no tiene asignada, ni crear pedidos en ella.
2. Transiciones inválidas rechazadas en el servidor.
3. Concurrencia: 10 pedidos de la misma obra enviados a la vez reciben 10 números distintos.
4. Orden aprobada: no editable; justificación obligatoria si no es la más barata.

Variables: ODOO_URL, ODOO_DB y NEXA_{RESIDENTE1,RESIDENTE2,GERENCIA,COMPRAS,TESORERIA}_{LOGIN,PASSWORD}.
Obras: NEXA_OBRA_A (asignada al residente 1) y NEXA_OBRA_B (asignada al residente 2).
Sale con código 0 solo si todo lo no autorizado fue rechazado.
"""
import os
import sys
import threading
import xmlrpc.client
from datetime import date

URL = os.environ["ODOO_URL"].rstrip("/")
DB = os.environ["ODOO_DB"]
OBRA_A = os.environ.get("NEXA_OBRA_A", "CT-2600-06")
OBRA_B = os.environ.get("NEXA_OBRA_B", "CT-2600-07")
fallos = []


def conectar(perfil):
    login, pwd = os.environ[f"NEXA_{perfil}_LOGIN"], os.environ[f"NEXA_{perfil}_PASSWORD"]
    uid = xmlrpc.client.ServerProxy(f"{URL}/xmlrpc/2/common").authenticate(DB, login, pwd, {})
    if not uid:
        sys.exit(f"No se pudo autenticar {perfil}")

    def call(model, method, *args, **kw):
        proxy = xmlrpc.client.ServerProxy(f"{URL}/xmlrpc/2/object", allow_none=True)
        return proxy.execute_kw(DB, uid, pwd, model, method, list(args), kw)
    return call


def motivo(fault):
    ruido = ("Si necesitas", "Póngase", "Contact your", "If you really")
    lineas = [l.strip() for l in fault.faultString.splitlines() if l.strip() and not l.strip().startswith(ruido)]
    claves = ("not allowed", "restricted", "no tiene acceso", "No puede acceder", "no puede", "Solo", "debe",
              "ya no", "no pertenece", "justificación", "Escriba", "sistema", "pedido aprobado", "Su perfil",
              "record rules", "does not exist", "máximo")
    i = next((i for i in range(len(lineas) - 1, -1, -1) if any(k in lineas[i] for k in claves)), len(lineas) - 1)
    texto = lineas[i] + (" " + lineas[i + 1] if i + 1 < len(lineas) and lineas[i + 1].startswith("-") else "")
    return texto[:160]


def debe_fallar(etiqueta, fn):
    try:
        r = fn()
    except xmlrpc.client.Fault as f:
        print(f"  RECHAZADO   {etiqueta}\n              servidor: {motivo(f)}")
        return
    if r in ([], False, None):
        print(f"  VACÍO       {etiqueta} (el servidor no devolvió nada)")
        return
    print(f"  ¡PERMITIDO! {etiqueta} -> {r!r:.120}  <-- FALLA")
    fallos.append(etiqueta)


def verificar(etiqueta, condicion):
    print(f"  {'OK         ' if condicion else '¡FALLA!    '} {etiqueta}")
    if not condicion:
        fallos.append(etiqueta)


r1, r2 = conectar("RESIDENTE1"), conectar("RESIDENTE2")
ger, com, tes = conectar("GERENCIA"), conectar("COMPRAS"), conectar("TESORERIA")
obra_a = ger("nexa.obra", "search", [("codigo", "=", OBRA_A)])[0]
obra_b = ger("nexa.obra", "search", [("codigo", "=", OBRA_B)])[0]
material = com("nexa.material", "search", [], limit=1) or [com("nexa.material", "create", {
    "codigo": "DEMO-CEM", "nombre": "Cemento demo", "unidad_medida": "bulto"})]
linea = [(0, 0, {"material_id": material[0], "cantidad": 10})]
print(f"Servidor {URL} · base {DB} · obra A={OBRA_A} (residente 1) · obra B={OBRA_B} (residente 2)\n")

print("1) Aislamiento por obra")
pb = r2("nexa.pedido", "create", {"obra_id": obra_b, "linea_ids": linea})
r2("nexa.pedido", "action_enviar", [pb])
cons_b = r2("nexa.pedido", "read", [pb], fields=["consecutivo"])[0]["consecutivo"]
print(f"  residente 2 creó el pedido {cons_b} en la obra B")
debe_fallar(f"residente 1 lee el pedido {cons_b} por su id", lambda: r1("nexa.pedido", "read", [pb], fields=["consecutivo", "linea_ids"]))
debe_fallar("residente 1 lo busca por id", lambda: r1("nexa.pedido", "search_read", [("id", "=", pb)], fields=["consecutivo"]))
debe_fallar("residente 1 lo edita", lambda: r1("nexa.pedido", "write", [pb], {"urgente": True}))
debe_fallar("residente 1 lee la obra B", lambda: r1("nexa.obra", "read", [obra_b], fields=["codigo"]))
debe_fallar("residente 1 crea un pedido en la obra B", lambda: r1("nexa.pedido", "create", {"obra_id": obra_b, "linea_ids": linea}))

print("\n2) Transiciones inválidas por API")
pa = r1("nexa.pedido", "create", {"obra_id": obra_a, "linea_ids": linea})
debe_fallar("residente escribe state='aprobado' directamente", lambda: r1("nexa.pedido", "write", [pa], {"state": "aprobado"}))
debe_fallar("residente escribe el consecutivo a mano", lambda: r1("nexa.pedido", "write", [pa], {"consecutivo": "A-P999"}))
r1("nexa.pedido", "action_enviar", [pa])
debe_fallar("residente se aprueba su propio pedido", lambda: r1("nexa.pedido", "action_aprobar", [pa]))
debe_fallar("residente edita un pedido ya enviado", lambda: r1("nexa.pedido", "write", [pa], {"urgente": True}))
debe_fallar("gerencia rechaza sin motivo", lambda: ger("nexa.pedido", "action_rechazar", [pa], ""))
ger("nexa.pedido", "action_rechazar", [pa], "Material ya disponible en bodega")
debe_fallar("compras crea orden sobre pedido RECHAZADO", lambda: com("nexa.orden.compra", "create", {"pedido_id": pa}))
debe_fallar("gerencia aprueba un pedido ya rechazado", lambda: ger("nexa.pedido", "action_aprobar", [pa]))

print("\n3) Concurrencia: 10 pedidos de la obra A enviados al mismo tiempo")
ids = [r1("nexa.pedido", "create", {"obra_id": obra_a, "linea_ids": linea}) for _ in range(10)]
barrera = threading.Barrier(len(ids))
errores = []


def enviar(pid):
    llamada = conectar("RESIDENTE1")
    barrera.wait()
    try:
        llamada("nexa.pedido", "action_enviar", [pid])
    except Exception as e:  # noqa: BLE001
        errores.append(str(e)[:120])


hilos = [threading.Thread(target=enviar, args=(i,)) for i in ids]
[h.start() for h in hilos]
[h.join() for h in hilos]
numeros = [p["consecutivo"] for p in r1("nexa.pedido", "read", ids, fields=["consecutivo"])]
print(f"  consecutivos: {sorted(numeros)}")
verificar(f"10 números distintos, sin repetidos ({len(set(numeros))} únicos, {len(errores)} errores)",
          len(set(numeros)) == 10 and not errores and all(numeros))

print("\n4) Orden de compra: elección, justificación y bloqueo")
pc = r1("nexa.pedido", "create", {"obra_id": obra_a, "linea_ids": linea})
r1("nexa.pedido", "action_enviar", [pc])
ger("nexa.pedido", "action_aprobar", [pc])
oc = com("nexa.orden.compra", "create", {"pedido_id": pc, "opcion_ids": [
    (0, 0, {"proveedor": "Proveedor 100", "precio_total": 100, "plazo_entrega_dias": 5, "forma_pago": "contado"}),
    (0, 0, {"proveedor": "Proveedor 130", "precio_total": 130, "plazo_entrega_dias": 1, "forma_pago": "crédito 30 días"}),
    (0, 0, {"proveedor": "Proveedor 90", "precio_total": 90, "plazo_entrega_dias": 15, "forma_pago": "anticipo 50 %"})]})
debe_fallar("agregar una cuarta opción", lambda: com("nexa.orden.compra", "write", [oc], {"opcion_ids": [
    (0, 0, {"proveedor": "Cuarta", "precio_total": 80, "plazo_entrega_dias": 3, "forma_pago": "contado"})]}))
com("nexa.orden.compra", "action_enviar", [oc])
opciones = com("nexa.opcion.cotizacion", "search_read", [("orden_id", "=", oc)], fields=["precio_total"])
op130 = next(o["id"] for o in opciones if o["precio_total"] == 130)
debe_fallar("gerencia elige 130 SIN justificación", lambda: ger("nexa.orden.compra", "action_aprobar", [oc], op130))
ger("nexa.orden.compra", "action_aprobar", [oc], op130, "Entrega en 1 día; la obra está detenida.")
o = ger("nexa.orden.compra", "read", [oc], fields=["consecutivo", "state", "aprobado_por_id", "aprobado_en"])[0]
print(f"  aprobada {o['consecutivo']} por {o['aprobado_por_id'][1]} en {o['aprobado_en']}")
debe_fallar("compras edita la orden aprobada", lambda: com("nexa.orden.compra", "write", [oc], {"pedido_id": pc}))
debe_fallar("compras cambia el precio de una opción aprobada", lambda: com("nexa.opcion.cotizacion", "write", [op130], {"precio_total": 1}))
debe_fallar("residente 1 lee la orden de compra", lambda: r1("nexa.orden.compra", "read", [oc], fields=["state"]))
debe_fallar("compras la marca pagada (no es tesorería)", lambda: com("nexa.orden.compra", "action_marcar_pagada", [oc], str(date.today()), "X"))
tes("nexa.orden.compra", "action_marcar_pagada", [oc], str(date.today()), "TRF-DEMO-001")
verificar("tesorería la marcó pagada", tes("nexa.orden.compra", "read", [oc], fields=["state"])[0]["state"] == "pagada")

print("\n5) Lo que ve el residente 1 al final")
visibles = r1("nexa.pedido", "search_read", [], fields=["consecutivo", "obra_id"])
verificar(f"ve {len(visibles)} pedidos y TODOS son de su obra {OBRA_A}",
          len(visibles) > 0 and all(v["obra_id"][0] == obra_a for v in visibles))

print("\nRESULTADO:", "OK — todo lo no autorizado fue rechazado por el servidor" if not fallos else f"FALLAS: {fallos}")
sys.exit(1 if fallos else 0)
