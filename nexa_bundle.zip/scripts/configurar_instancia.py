"""Configuración inicial de la instancia. Se ejecuta con `odoo shell`.

* Empresa en Colombia, moneda COP.
* Usuarios de los dos perfiles con credenciales tomadas de variables de entorno:
    NEXA_COMPRAS_LOGIN, NEXA_COMPRAS_PASSWORD
    NEXA_CONSULTA_LOGIN, NEXA_CONSULTA_PASSWORD
* Idioma es_CO y zona horaria de Bogotá para esos usuarios.

Es idempotente: se puede correr varias veces.
"""
import os

env = env  # noqa: F821  (inyectado por `odoo shell`)

# Adjuntos (incluidos los paquetes CSS/JS de la interfaz) dentro de PostgreSQL:
# así la instancia no depende de un disco persistente (plan gratis sin disco).
if os.environ.get("NEXA_ADJUNTOS_EN_BD", "1") == "1":
    env["ir.config_parameter"].sudo().set_param("ir_attachment.location", "db")
    env["ir.attachment"].force_storage()
    print("adjuntos: almacenados en la base de datos")

# Tras instalar o migrar, se borran los paquetes CSS/JS compilados: Odoo los
# regenera en la primera visita. Evita paquetes viejos que apunten a archivos
# de un disco que ya no existe (plan gratis sin disco persistente).
viejos = env["ir.attachment"].sudo().search([("url", "=like", "/web/assets/%")])
print(f"paquetes de interfaz regenerables borrados: {len(viejos)}")
viejos.unlink()
cop = env.ref("base.COP")
cop.active = True
company = env.company
company.write({
    "name": os.environ.get("NEXA_EMPRESA", "Constructora (demo NEXA)"),
    "country_id": env.ref("base.co").id,
    "currency_id": cop.id,
})
print(f"empresa: {company.name} · país CO · moneda {company.currency_id.name}")

perfiles = [
    ("Compras (demo)", "NEXA_COMPRAS", "nexa_materiales.group_materiales_compras"),
    ("Consulta (demo)", "NEXA_CONSULTA", "nexa_materiales.group_materiales_consulta"),
    ("Residente 1 (demo)", "NEXA_RESIDENTE1", "nexa_materiales.group_compras_residente"),
    ("Residente 2 (demo)", "NEXA_RESIDENTE2", "nexa_materiales.group_compras_residente"),
    ("Gerencia (demo)", "NEXA_GERENCIA", "nexa_materiales.group_compras_gerencia"),
    ("Tesorería (demo)", "NEXA_TESORERIA", "nexa_materiales.group_compras_tesoreria"),
]
Users = env["res.users"].sudo().with_context(active_test=False)
for nombre, prefijo, grupo in perfiles:
    if not os.environ.get(f"{prefijo}_LOGIN") or not os.environ.get(f"{prefijo}_PASSWORD"):
        print(f"perfil {prefijo}: sin credenciales en el entorno, se omite")
        continue
    login = os.environ[f"{prefijo}_LOGIN"]
    vals = {
        "name": nombre, "login": login, "password": os.environ[f"{prefijo}_PASSWORD"],
        "groups_id": [(6, 0, [env.ref("base.group_user").id, env.ref(grupo).id])],
        "active": True, "lang": "es_CO", "tz": "America/Bogota",
    }
    user = Users.search([("login", "=", login)])
    user.write(vals) if user else Users.create(vals)
    print(f"usuario listo: {login} -> {grupo}")

# Obras de demostración (opcional): dos obras y cada residente de demo en una.
if os.environ.get("NEXA_DATOS_DEMO") == "1":
    Obra = env["nexa.obra"].sudo().with_context(active_test=False)
    for codigo, nombre, login_env in (("CT-2600-06", "Planta de tratamiento (demo)", "NEXA_RESIDENTE1_LOGIN"),
                                      ("CT-2600-07", "Bodega industrial (demo)", "NEXA_RESIDENTE2_LOGIN")):
        obra = Obra.search([("codigo", "=", codigo)])
        if not obra:
            obra = Obra.create({"codigo": codigo, "nombre": nombre, "presupuesto_materiales": 250_000_000})
        residente = env["res.users"].sudo().search([("login", "=", os.environ.get(login_env, ""))], limit=1)
        if residente and residente not in obra.residente_ids.usuario_id:
            obra.write({"residente_ids": [(0, 0, {"usuario_id": residente.id})]})
        print(f"obra demo: {codigo} -> {residente.login or 'sin residente'}")

# El administrador nunca queda con la clave por defecto "admin".
admin_pwd = os.environ.get("NEXA_ADMIN_PASSWORD") or os.environ["ODOO_ADMIN_PASSWD"]
env.ref("base.user_admin").write({"lang": "es_CO", "tz": "America/Bogota", "password": admin_pwd})
print("administrador: clave tomada de variable de entorno")
env.cr.commit()
